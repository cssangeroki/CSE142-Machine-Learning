Included in this .zip file are codes for LogisticRegression, LogisticRegression_withBias, and LogisticRegression_withRegularization. 

The code solves Problem 3 for Assignment 4
